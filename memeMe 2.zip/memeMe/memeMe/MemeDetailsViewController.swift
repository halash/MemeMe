//
//  MemeDetailsViewController.swift
//  memeMe
//
//  Created by hala shaki on 02/12/2018.
//  Copyright © 2018 hala shaki. All rights reserved.
//

import UIKit

class MemeDetailsViewController: UIViewController {
 
    var meme : Meme!
    var m : Meme!
   
    @IBOutlet weak var imgMemeDetails: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        
        var items = navigationItem.rightBarButtonItems
        if items == nil {
            items = [UIBarButtonItem]()
        }
        items! += [editButtonItem]
        navigationItem.rightBarButtonItems = items
         self.imgMemeDetails.image = self.meme.memedImage
         m = self.meme
        
    }
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        
         displayView(withIdentifier: "MainController")
    }
    
    func displayView(withIdentifier: String)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let collectionViewController = storyBoard.instantiateViewController(withIdentifier: withIdentifier) as? MemeMeViewController
        self.present(collectionViewController!, animated: true, completion:
            {
                collectionViewController?.cancelButton.isEnabled = true
                collectionViewController?.shareButton.isEnabled = true
                collectionViewController?.imagePickViewer.image = self.meme.originalImage
                collectionViewController?.topTextField.text = self.meme.topText
                collectionViewController?.bottomTextField.text = self.meme.bottomText
        })
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
        
    }
  
}
