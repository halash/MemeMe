//
//  MemeTableViewCell.swift
//  memeMe
//
//  Created by hala shaki on 02/12/2018.
//  Copyright © 2018 hala shaki. All rights reserved.
//

import UIKit

class MemeTableViewCell: UITableViewCell {

   
    @IBOutlet weak var imgTable: UIImageView!
    @IBOutlet weak var lblTable: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

  
    
}
