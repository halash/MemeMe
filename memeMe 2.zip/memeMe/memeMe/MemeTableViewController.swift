//
//  MemeTableViewController.swift
//  memeMe
//
//  Created by hala shaki on 02/12/2018.
//  Copyright © 2018 hala shaki. All rights reserved.
//

import UIKit

class MemeTableViewController: UIViewController {
  
    var meme : [Meme]!
    {
        let object = UIApplication.shared.delegate as? AppDelegate
        return object?.memes
    }
    
    @IBAction func AddNewMeme(_ sender: Any) {
   
        displayView(withIdentifier: "MainController")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func displayView(withIdentifier: String)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let collectionViewController = storyBoard.instantiateViewController(withIdentifier: withIdentifier) as? MemeMeViewController
        
        self.present(collectionViewController!, animated: true, completion:
            {
                collectionViewController?.cancelButton.isEnabled = true
        })
    }

   
}


extension  MemeTableViewController: UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meme.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath) as! MemeTableViewCell
        let meme = self.meme[indexPath.row]
        cell.imgTable.image = meme.memedImage
        cell.lblTable.text = meme.topText + "...." + meme.bottomText
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailsViewController") as!  MemeDetailsViewController
        detailController.meme = self.meme[(indexPath as NSIndexPath).row]
        self.navigationController!.pushViewController(detailController, animated: true)
        
        
    }
    
    
}
