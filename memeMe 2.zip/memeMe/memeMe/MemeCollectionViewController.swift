//
//  MemeCollectionViewController.swift
//  memeMe
//
//  Created by hala shaki on 01/12/2018.
//  Copyright © 2018 hala shaki. All rights reserved.
//

import UIKit


class MemeCollectionViewController: UIViewController{

    var meme : [Meme]!
    {
        let object = UIApplication.shared.delegate as? AppDelegate
        return object?.memes
    }
    
    @IBOutlet var memeCollectionView: UICollectionView!
    @IBAction func addNewMeme(_ sender: Any) {
      
        displayView(withIdentifier: "MainController")
       
    }
    
    func displayView(withIdentifier: String)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let collectionViewController = storyBoard.instantiateViewController(withIdentifier: withIdentifier) as? MemeMeViewController
    
        self.present(collectionViewController!, animated: true, completion:
        {
            collectionViewController?.cancelButton.isEnabled = true
        })
    }
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
}

extension MemeCollectionViewController:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return meme.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionCell", for: indexPath) as! CollectionViewCell
        
        let meme = self.meme[indexPath.row]
        cell.imgCollection.image = meme.memedImage
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
            let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailsViewController") as!  MemeDetailsViewController
            detailController.meme = self.meme[(indexPath as NSIndexPath).row]
            self.navigationController!.pushViewController(detailController, animated: true)
            
        }


}

extension  MemeCollectionViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        var width = UIScreen.main.bounds.width
        layout.sectionInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        width = width - 30
        return CGSize(width: width / 3, height: width / 3)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
}
