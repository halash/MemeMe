//
//  ViewController.swift
//  memeMe
//
//  Created by hala shaki on 16/11/2018.
//  Copyright © 2018 hala shaki. All rights reserved.
//

import UIKit




  class MemeMeViewController: UIViewController   {
    
    @IBOutlet weak var imagePickViewer: UIImageView!
   
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
    @IBOutlet weak var albumButton: UIBarButtonItem!
    
    @IBOutlet weak var toolbarBottom: UIToolbar!
    
    @IBOutlet weak var topTextField: UITextField!
    
    @IBOutlet weak var  cancelButton: UIBarButtonItem!
    
    @IBOutlet weak var bottomTextField: UITextField!
    
    @IBOutlet weak var toolBarBottom: UIToolbar!
 
    @IBOutlet weak var navigationBarTop: UINavigationBar!
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    
  
    
    var activeTextField = UITextField()
    
  
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.adjustsFontSizeToFitWidth = true
        activeTextField = textField
        //Erase the default text when editing
        if textField == topTextField && topTextField.text == "TOP" {
            textField.text = ""
            
        } else if textField == bottomTextField && bottomTextField .text == "BOTTOM" {
            textField.text = ""
        }
    }
    
    
    //when pressing the return button on keyboard the keyboard is closed
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       return textField.resignFirstResponder()
    }
    
 
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        setTextFieldStyle(textFieldId: topTextField)
        setTextFieldStyle(textFieldId: bottomTextField)
        
    }

    @IBAction func shareImageButton(_ sender: Any) {
       
        let memedImage = generateMemedImage()
        let viewActivityVC = UIActivityViewController(activityItems:[memedImage]  , applicationActivities: nil)
        viewActivityVC.popoverPresentationController?.sourceView = self.view
        self.present(viewActivityVC, animated: true, completion: nil)
        viewActivityVC.completionWithItemsHandler = {
            (activityType, completed, returnedItems, activityError) in
            if completed {
                self.save(memedImage : memedImage)
              //  self.dismiss(animated: true, completion: nil)
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let collectionViewController = storyBoard.instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
                self.present(collectionViewController, animated: true, completion: nil)

            }
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        subscribeToKeyboardNotifications()
         shareButton.isEnabled =   imagePickViewer.image == nil ? false : true
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }

    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
         NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification , object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    @objc func keyboardWillShow(_ notification:Notification) {
        
        if self.activeTextField == bottomTextField {
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
    }
    
    @objc func keyboardWillHide(_ notification:Notification)
    {
       view.frame.origin.y = 0
    }
    
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
    
    
    
    @IBAction func pickAnImage(_ sender: Any) {
    
        pickAnImage(sourceType : .photoLibrary)
  
    }

    @IBAction func pickAnImageFromCamera(_ sender: Any) {
       
         pickAnImage(sourceType : .camera)
    }
    
    
    
    func pickAnImage(sourceType :  UIImagePickerController.SourceType)
    {
        if sourceType == .camera
        {
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                openImagePicker(sourceType)
            }else
            {
                let alert = UIAlertController()
                alert.title = "Warning"
                alert.message = "Camera is not aviable on simulation"
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.cancel, handler: nil))
                present(alert, animated: true, completion: nil)
            }
        }else if sourceType == .photoLibrary
        {
            openImagePicker(sourceType)
        }
    }
    
    func openImagePicker(_ type: UIImagePickerController.SourceType){
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = type
        present(picker, animated: true, completion: nil)
       
    }
    
    
    func setTextFieldStyle(textFieldId : UITextField)
    {
      
        let memeTextAttributes:[NSAttributedString.Key : Any] = [
            NSAttributedString.Key.strokeColor: UIColor.black,
            NSAttributedString.Key.foregroundColor: UIColor.white,
            NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
            NSAttributedString.Key.strokeWidth: -4.0]
            textFieldId.defaultTextAttributes = memeTextAttributes
            textFieldId.textAlignment = .center
            textFieldId.autocapitalizationType = .allCharacters
            textFieldId.delegate = self
        
    }
   
    
    func save(memedImage : UIImage) {
        // Create the meme
        let meme = Meme(topText: topTextField.text!, bottomText: bottomTextField.text!, originalImage: imagePickViewer.image!, memedImage: memedImage)
     
        //Version 2.0
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme)        
    }
    
    @IBAction func cancelAddNewMeme(_ sender: Any) {
        dismiss(animated: true, completion: nil)

    }
    
    func generateMemedImage() -> UIImage {
        
        hideToolbars(hidden: true)
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        hideToolbars(hidden: false)
        
        return memedImage
    }
    
    
    func hideToolbars(hidden : Bool)
    {
        toolBarBottom.isHidden = hidden
        navigationBarTop.isHidden = hidden
    }
    
}


extension MemeMeViewController : UIImagePickerControllerDelegate,
UINavigationControllerDelegate,UITextFieldDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
         if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imagePickViewer.contentMode = .scaleAspectFit
            imagePickViewer.image = pickedImage
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

