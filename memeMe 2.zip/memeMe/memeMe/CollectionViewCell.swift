//
//  CollectionViewCell.swift
//  memeMe
//
//  Created by hala shaki on 02/12/2018.
//  Copyright © 2018 hala shaki. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imgCollection: UIImageView!
   
   
}
